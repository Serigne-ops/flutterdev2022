class UserModel {
  final String uid;
  final String nom;
  final String email;
  final String role;
  final String? telephone;
  final String? region;

  // Expert
  final String? specialite;
  final int? experience;

  // Acheteur
  final String? entreprise;
  final String? typeAcheteur;

  UserModel({
    required this.uid,
    required this.nom,
    required this.email,
    required this.role,
    this.telephone,
    this.region,
    this.specialite,
    this.experience,
    this.entreprise,
    this.typeAcheteur,
  });

  Map<String, dynamic> toMap() {
    return {
      'nom': nom,
      'email': email,
      'role': role,
      'telephone': telephone,
      'region': region,
      'specialite': specialite,
      'experience': experience,
      'entreprise': entreprise,
      'typeAcheteur': typeAcheteur,
    };
  }

  factory UserModel.fromMap(String uid, Map<String, dynamic> map) {
    return UserModel(
      uid: uid,
      nom: map['nom'],
      email: map['email'],
      role: map['role'],
      telephone: map['telephone'],
      region: map['region'],
      specialite: map['specialite'],
      experience: map['experience'],
      entreprise: map['entreprise'],
      typeAcheteur: map['typeAcheteur'],
    );
  }
}
