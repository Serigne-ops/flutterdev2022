class Culture {
  final String id;
  final String nom;
  final String description;
  final String saison;
  final String conseils;

  Culture({
    required this.id,
    required this.nom,
    required this.description,
    required this.saison,
    required this.conseils,
  });

  factory Culture.fromMap(String id, Map<String, dynamic> data) {
    return Culture(
      id: id,
      nom: data['nom'],
      description: data['description'],
      saison: data['saison'],
      conseils: data['conseils'],
    );
  }
}
