class Meteo {
  final double temp;
  final int humidity;
  final double wind;
  final String description;
  final String icon;

  Meteo({
    required this.temp,
    required this.humidity,
    required this.wind,
    required this.description,
    required this.icon,
  });

  factory Meteo.fromJson(Map<String, dynamic> json) {
    return Meteo(
      temp: json['main']['temp'].toDouble(),
      humidity: json['main']['humidity'],
      wind: json['wind']['speed'].toDouble(),
      description: json['weather'][0]['description'],
      icon: json['weather'][0]['icon'],
    );
  }
}
