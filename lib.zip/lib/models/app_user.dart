class AppUser {
  final String uid;
  final String nom;
  final String email;
  final String role;
  final String region;
  final String? specialite;
  final String? entreprise;

  AppUser({
    required this.uid,
    required this.nom,
    required this.email,
    required this.role,
    required this.region,
    this.specialite,
    this.entreprise,
  });

  factory AppUser.fromMap(String uid, Map<String, dynamic> data) {
    return AppUser(
      uid: uid,
      nom: data['nom'],
      email: data['email'],
      role: data['role'],
      region: data['region'],
      specialite: data['specialite'],
      entreprise: data['entreprise'],
    );
  }
}
