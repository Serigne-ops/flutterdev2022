class MarketPost {
  final String id;
  final String userId;
  final String userRole;
  final String produit;
  final String description;
  final int prix;
  final String unite;
  final int quantite;
  final String region;

  MarketPost({
    required this.id,
    required this.userId,
    required this.userRole,
    required this.produit,
    required this.description,
    required this.prix,
    required this.unite,
    required this.quantite,
    required this.region,
  });

  factory MarketPost.fromMap(String id, Map<String, dynamic> data) {
    return MarketPost(
      id: id,
      userId: data['userId'],
      userRole: data['userRole'],
      produit: data['produit'],
      description: data['description'],
      prix: data['prix'],
      unite: data['unite'],
      quantite: data['quantite'],
      region: data['region'],
    );
  }
}
