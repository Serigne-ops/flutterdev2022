class Conseil {
  final String culture;
  final String saison;
  final String conseil;

  Conseil({required this.culture, required this.saison, required this.conseil});

  factory Conseil.fromMap(Map<String, dynamic> map) {
    return Conseil(
      culture: map['culture'] ?? '',
      saison: map['saison'] ?? '',
      conseil: map['conseil'] ?? '',
    );
  }
}
