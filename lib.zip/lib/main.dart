import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'pages/login_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const SunuAgriApp());
}

class SunuAgriApp extends StatelessWidget {
  const SunuAgriApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SunuAgri',
      theme: ThemeData(primarySwatch: Colors.green),
      routes: {'/login': (_) => const LoginPage()},
      home: const LoginPage(),
    );
  }
}
