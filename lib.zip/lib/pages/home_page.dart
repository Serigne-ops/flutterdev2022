import 'package:flutter/material.dart';
import 'accueil_page.dart';
import 'messages_page.dart';
import 'notifications_page.dart';
import 'cultures_page.dart';
import 'forum_page.dart';
import 'marche_page.dart';
import 'meteo_page.dart';
import 'profile_page.dart';
import 'package:firebase_auth/firebase_auth.dart';

class HomePage extends StatefulWidget {
  final String role;

  const HomePage({super.key, required this.role});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  late final List<Widget> _bottomPages;

  @override
  void initState() {
    super.initState();

    _bottomPages = const [AccueilPage(), MessagesPage(), NotificationsPage()];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("SunuAgri "),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Recherche cliquée")),
              );
            },
          ),

          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'profil') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfilePage()),
                );
              }

              if (value == 'about') {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text("À propos"),
                    content: const Text(
                      "SunuAgri est une plateforme agricole "
                      "pour agriculteurs, techniciens et acheteurs.",
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text("OK"),
                      ),
                    ],
                  ),
                );
              }

              if (value == 'logout') {
                await FirebaseAuth.instance.signOut();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    '/login',
                    (_) => false,
                  );
                }
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'profil', child: Text("Mon profil")),
              PopupMenuItem(value: 'about', child: Text("À propos")),
              PopupMenuDivider(),
              PopupMenuItem(
                value: 'logout',
                child: Text("Déconnexion", style: TextStyle(color: Colors.red)),
              ),
            ],
          ),
        ],
      ),

      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: Text(
                "Menu SunuAgri",
                style: TextStyle(color: Colors.white, fontSize: 22),
              ),
            ),

            if (widget.role != 'acheteur')
              _drawerItem(Icons.person, "Profil", const ProfilePage()),
            _drawerItem(Icons.forum, "Forum", ForumPage()),

            _drawerItem(Icons.store, "Marché", const MarchePage()),
            _drawerItem(Icons.cloud, "Météo", const MeteoPage()),

            if (widget.role == 'agriculteur')
              _drawerItem(Icons.grass, "Cultures", const CulturesPage()),
          ],
        ),
      ),

      body: _bottomPages[_currentIndex],

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.green,
        onTap: (index) {
          setState(() => _currentIndex = index);
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Accueil"),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: "Messages"),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: "Notifications",
          ),
        ],
      ),
    );
  }

  ListTile _drawerItem(IconData icon, String title, Widget page) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => page));
      },
    );
  }
}
