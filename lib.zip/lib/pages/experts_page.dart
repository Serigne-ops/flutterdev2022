import 'package:flutter/material.dart';
import '../services/user_service.dart';
import '../models/user_model.dart';

class ExpertsPage extends StatelessWidget {
  const ExpertsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Experts agricoles")),
      body: StreamBuilder<List<UserModel>>(
        stream: UserService().getExperts(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text("Erreur de chargement"));
          }

          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final experts = snapshot.data!;

          if (experts.isEmpty) {
            return const Center(child: Text("Aucun expert disponible"));
          }

          return ListView.builder(
            itemCount: experts.length,
            itemBuilder: (context, index) {
              final expert = experts[index];
              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  leading: const Icon(Icons.verified, color: Colors.green),
                  title: Text(expert.nom),
                  subtitle: Text(
                    "Spécialité : ${expert.specialite ?? 'Non précisée'}",
                  ),
                  trailing: Text("${expert.experience ?? 0} ans"),
                  onTap: () {
                    // plus tard : profil expert détaillé
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
