import 'package:flutter/material.dart';

class CulturesPage extends StatelessWidget {
  const CulturesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Cultures")),
      body: const Center(child: Text("Conseils de cultures")),
    );
  }
}
