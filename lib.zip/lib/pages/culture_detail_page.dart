import 'package:flutter/material.dart';
import '../models/culture.dart';

class CultureDetailPage extends StatelessWidget {
  final Culture culture;

  const CultureDetailPage({super.key, required this.culture});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(culture.nom)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(culture.description, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 20),
            Text(" Saison : ${culture.saison}"),
            const SizedBox(height: 10),
            const Text(
              " Conseils agricoles",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            Text(culture.conseils),
          ],
        ),
      ),
    );
  }
}
