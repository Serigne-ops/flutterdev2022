import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class MeteoPage extends StatefulWidget {
  const MeteoPage({super.key});

  @override
  State<MeteoPage> createState() => _MeteoPageState();
}

class _MeteoPageState extends State<MeteoPage> {
  Map<String, dynamic>? meteo;
  bool loading = true;

  final String apiKey = "TON_API_KEY_ICI";

  @override
  void initState() {
    super.initState();
    fetchMeteo();
  }

  Future<void> fetchMeteo() async {
    const city = "Dakar";
    final url =
        "https://api.openweathermap.org/data/2.5/weather?q=$city&units=metric&lang=fr&appid=$apiKey";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      setState(() {
        meteo = json.decode(response.body);
        loading = false;
      });
    } else {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Météo agricole ")),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : meteo == null
          ? const Center(child: Text("Impossible de charger la météo"))
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    meteo!['name'],
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "${meteo!['main']['temp']} °C",
                    style: const TextStyle(fontSize: 40),
                  ),
                  Text(
                    meteo!['weather'][0]['description'],
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 20),
                  Text("Humidité : ${meteo!['main']['humidity']}%"),
                  Text("Vent : ${meteo!['wind']['speed']} m/s"),
                  const SizedBox(height: 30),
                  const Text(
                    "Conseil agricole :",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const Text("Arrosage conseillé si aucune pluie prévue."),
                ],
              ),
            ),
    );
  }
}
