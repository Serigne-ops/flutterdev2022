import 'package:flutter/material.dart';

class AccueilPage extends StatelessWidget {
  const AccueilPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Bienvenue sur SunuAgri ", style: TextStyle(fontSize: 22)),
    );
  }
}
