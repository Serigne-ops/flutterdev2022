import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddConseilPage extends StatefulWidget {
  const AddConseilPage({super.key});

  @override
  State<AddConseilPage> createState() => _AddConseilPageState();
}

class _AddConseilPageState extends State<AddConseilPage> {
  final TextEditingController cultureController = TextEditingController();
  final TextEditingController conseilController = TextEditingController();
  final TextEditingController regionController = TextEditingController();

  Future<void> ajouterConseil() async {
    final user = FirebaseAuth.instance.currentUser;

    if (cultureController.text.isEmpty ||
        conseilController.text.isEmpty ||
        regionController.text.isEmpty) {
      return;
    }

    await FirebaseFirestore.instance.collection("conseils_cultures").add({
      "culture": cultureController.text,
      "conseil": conseilController.text,
      "region": regionController.text,
      "auteur": user!.uid,
      "date": FieldValue.serverTimestamp(),
    });
    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ajouter un conseil")),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [
            TextField(
              controller: cultureController,
              decoration: const InputDecoration(labelText: "Culture (ex: Riz)"),
            ),

            const SizedBox(height: 15),

            TextField(
              controller: conseilController,
              decoration: const InputDecoration(labelText: "Conseil agricole"),
              maxLines: 3,
            ),

            const SizedBox(height: 15),

            TextField(
              controller: regionController,
              decoration: const InputDecoration(labelText: "Région"),
            ),

            const SizedBox(height: 25),

            ElevatedButton(
              onPressed: ajouterConseil,
              child: const Text("Publier le conseil"),
            ),
          ],
        ),
      ),
    );
  }
}
