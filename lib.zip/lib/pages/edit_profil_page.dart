import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController nomController = TextEditingController();
  final TextEditingController telephoneController = TextEditingController();
  final TextEditingController localiteController = TextEditingController();

  final user = FirebaseAuth.instance.currentUser;

  Future<void> updateProfile() async {
    await FirebaseFirestore.instance.collection("users").doc(user!.uid).update({
      "nom": nomController.text,
      "telephone": telephoneController.text,
      "localite": localiteController.text,
    });

    if (!mounted) return;

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Profil mis à jour")));

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Modifier Profil")),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: Form(
          key: _formKey,

          child: Column(
            children: [
              TextFormField(
                controller: nomController,
                decoration: const InputDecoration(labelText: "Nom"),
              ),

              const SizedBox(height: 10),

              TextFormField(
                controller: telephoneController,
                decoration: const InputDecoration(labelText: "Téléphone"),
              ),

              const SizedBox(height: 10),

              TextFormField(
                controller: localiteController,
                decoration: const InputDecoration(labelText: "Localité"),
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: updateProfile,
                child: const Text("Enregistrer"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
