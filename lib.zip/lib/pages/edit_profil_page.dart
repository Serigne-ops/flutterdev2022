import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();

  final nomController = TextEditingController();
  final telephoneController = TextEditingController();
  final localiteController = TextEditingController();

  String role = "Agriculteur";

  final user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    if (user == null) return;

    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user!.uid)
        .get();

    if (doc.exists) {
      final data = doc.data()!;
      nomController.text = data['nom'] ?? "";
      telephoneController.text = data['telephone'] ?? "";
      localiteController.text = data['localite'] ?? "";
      role = data['role'] ?? "Agriculteur";
      setState(() {});
    }
  }

  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate() || user == null) return;

    await FirebaseFirestore.instance.collection('users').doc(user!.uid).update({
      "nom": nomController.text,
      "telephone": telephoneController.text,
      "localite": localiteController.text,
      "role": role,
    });

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Modifier le profil")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _field("Nom", nomController),
              _field("Téléphone", telephoneController),
              _field("Localité", localiteController),

              const SizedBox(height: 12),

              DropdownButtonFormField<String>(
                initialValue: role,
                items: const [
                  DropdownMenuItem(
                    value: "Agriculteur",
                    child: Text("Agriculteur"),
                  ),
                  DropdownMenuItem(value: "Expert", child: Text("Expert")),
                  DropdownMenuItem(value: "Acheteur", child: Text("Acheteur")),
                ],
                onChanged: (value) {
                  setState(() {
                    role = value!;
                  });
                },
                decoration: const InputDecoration(
                  labelText: "Rôle",
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: _updateProfile,
                child: const Text("Enregistrer"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        validator: (v) => v == null || v.isEmpty ? "Champ obligatoire" : null,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
