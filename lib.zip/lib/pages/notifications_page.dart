import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/notification_service.dart';

class NotificationsPage extends StatelessWidget {
  NotificationsPage({super.key});

  final NotificationService service = NotificationService();

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: const Text("Notifications")),

      body: StreamBuilder(
        stream: service.getNotifications(uid),

        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final notifications = snapshot.data!.docs;

          if (notifications.isEmpty) {
            return const Center(child: Text("Aucune notification"));
          }

          return ListView.builder(
            itemCount: notifications.length,

            itemBuilder: (context, index) {
              final data = notifications[index].data() as Map;

              return ListTile(
                leading: const Icon(Icons.notifications),
                title: Text(data["title"]),
                subtitle: Text(data["body"]),
              );
            },
          );
        },
      ),
    );
  }
}
