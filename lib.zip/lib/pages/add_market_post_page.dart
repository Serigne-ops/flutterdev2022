import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/market_service.dart';

class AddMarketPostPage extends StatefulWidget {
  const AddMarketPostPage({super.key});

  @override
  State<AddMarketPostPage> createState() => _AddMarketPostPageState();
}

class _AddMarketPostPageState extends State<AddMarketPostPage> {
  final _produit = TextEditingController();
  final _description = TextEditingController();
  final _prix = TextEditingController();
  final _quantite = TextEditingController();
  final _region = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Nouvelle annonce")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _produit,
              decoration: const InputDecoration(labelText: "Produit"),
            ),
            TextField(
              controller: _description,
              decoration: const InputDecoration(labelText: "Description"),
            ),
            TextField(
              controller: _prix,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Prix"),
            ),
            TextField(
              controller: _quantite,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Quantité"),
            ),
            TextField(
              controller: _region,
              decoration: const InputDecoration(labelText: "Région"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              child: const Text("Publier"),
              onPressed: () async {
                final user = FirebaseAuth.instance.currentUser!;
                await MarketService().addPost({
                  'userId': user.uid,
                  'userRole': 'agriculteur', // ou acheteur selon ton AppUser
                  'produit': _produit.text,
                  'description': _description.text,
                  'prix': int.parse(_prix.text),
                  'unite': 'kg',
                  'quantite': int.parse(_quantite.text),
                  'region': _region.text,
                });
                if (!context.mounted) return;
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
