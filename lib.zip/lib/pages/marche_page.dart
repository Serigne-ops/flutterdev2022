import 'package:flutter/material.dart';
import '../services/market_service.dart';
import '../models/market_post.dart';
import 'add_market_post_page.dart';

class MarchePage extends StatelessWidget {
  const MarchePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Marché "),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddMarketPostPage()),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<List<MarketPost>>(
        stream: MarketService().getMarketPosts(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final posts = snapshot.data!;

          if (posts.isEmpty) {
            return const Center(child: Text("Aucune annonce disponible"));
          }

          return ListView.builder(
            itemCount: posts.length,
            itemBuilder: (context, index) {
              final post = posts[index];

              return Card(
                margin: const EdgeInsets.all(10),
                child: ListTile(
                  title: Text(
                    "${post.produit} - ${post.prix} FCFA/${post.unite}",
                  ),
                  subtitle: Text(
                    "${post.quantite} ${post.unite} • ${post.region}\n${post.description}",
                  ),
                  trailing: Chip(
                    label: Text(post.userRole),
                    backgroundColor: post.userRole == 'agriculteur'
                        ? Colors.green.shade100
                        : Colors.blue.shade100,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
