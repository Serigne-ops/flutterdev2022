import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError('Linux non configuré.');
      default:
        throw UnsupportedError('Plateforme non supportée.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyC3hR3av7-WyduaSGyMrQQeehrbseMjuP0',
    appId: '1:576456330478:android:91dec0d26b88d15aec77ff',
    messagingSenderId: '576456330478',
    projectId: 'sunuagri-f0756',
    storageBucket: 'sunuagri-f0756.firebasestorage.app',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAy_Qpploj8PR6J3gF96WlIhodAntnjek8',
    appId: '1:576456330478:web:283c89069596774dec77ff',
    messagingSenderId: '576456330478',
    projectId: 'sunuagri-f0756',
    authDomain: 'sunuagri-f0756.firebaseapp.com',
    storageBucket: 'sunuagri-f0756.firebasestorage.app',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyD-xsmLQxK6-efvrZ47WNyPUtYpmyZdTco',
    appId: '1:576456330478:ios:6f5674f89b86c671ec77ff',
    messagingSenderId: '576456330478',
    projectId: 'sunuagri-f0756',
    storageBucket: 'sunuagri-f0756.firebasestorage.app',
    iosBundleId: 'sn.edu.ugb.SunuAgri.sunuagri',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyD-xsmLQxK6-efvrZ47WNyPUtYpmyZdTco',
    appId: '1:576456330478:ios:6f5674f89b86c671ec77ff',
    messagingSenderId: '576456330478',
    projectId: 'sunuagri-f0756',
    storageBucket: 'sunuagri-f0756.firebasestorage.app',
    iosBundleId: 'sn.edu.ugb.SunuAgri.sunuagri',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyAy_Qpploj8PR6J3gF96WlIhodAntnjek8',
    appId: '1:576456330478:web:0c2ab26ae308c448ec77ff',
    messagingSenderId: '576456330478',
    projectId: 'sunuagri-f0756',
    authDomain: 'sunuagri-f0756.firebaseapp.com',
    storageBucket: 'sunuagri-f0756.firebasestorage.app',
  );

}