import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot> getNotifications(String userId) {
    return _db
        .collection("notifications")
        .where("userId", isEqualTo: userId)
        .orderBy("createdAt", descending: true)
        .snapshots();
  }

  Future<void> sendNotification({
    required String userId,
    required String title,
    required String body,
  }) async {
    await _db.collection("notifications").add({
      "userId": userId,
      "title": title,
      "body": body,
      "createdAt": FieldValue.serverTimestamp(),
      "read": true,
    });
  }
}
