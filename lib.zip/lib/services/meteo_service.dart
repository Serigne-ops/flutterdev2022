import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/meteo_model.dart';

class MeteoService {
  static const String apiKey = "TA_CLE_API_ICI";

  Future<Meteo> getMeteo(double lat, double lon) async {
    final url =
        "https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&units=metric&lang=fr&appid=$apiKey";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      return Meteo.fromJson(json.decode(response.body));
    } else {
      throw Exception("Erreur météo");
    }
  }
}
