import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/post.dart';

class PostService {
  final _posts = FirebaseFirestore.instance.collection('posts');

  Stream<List<Post>> getPosts() {
    return _posts
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => Post.fromFirestore(doc)).toList(),
        );
  }

  Future<void> addPost({
    required String title,
    required String content,
    required String authorId,
    required String authorName,
  }) async {
    await _posts.add({
      'title': title,
      'content': content,
      'authorId': authorId,
      'authorName': authorName,
      'createdAt': Timestamp.now(),
      'likes': 0,
    });
  }
}
