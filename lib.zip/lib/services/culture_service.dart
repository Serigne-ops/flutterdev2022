import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/culture.dart';

class CultureService {
  final _db = FirebaseFirestore.instance;

  Stream<List<Culture>> getCultures() {
    return _db
        .collection('cultures')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => Culture.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }
}
