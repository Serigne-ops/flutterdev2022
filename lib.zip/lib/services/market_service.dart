import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/market_post.dart';

class MarketService {
  final _db = FirebaseFirestore.instance;

  Stream<List<MarketPost>> getMarketPosts() {
    return _db
        .collection('market_posts')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => MarketPost.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  Future<void> addPost(Map<String, dynamic> data) async {
    await _db.collection('market_posts').add({
      ...data,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
