import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'notification_service.dart';

class ChatService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String getChatId(String otherUserId) {
    final currentUser = _auth.currentUser!.uid;

    if (currentUser.compareTo(otherUserId) > 0) {
      return "$currentUser-$otherUserId";
    } else {
      return "$otherUserId-$currentUser";
    }
  }

  Future<void> sendMessage(String otherUserId, String text) async {
    final currentUser = _auth.currentUser!.uid;

    final chatId = getChatId(otherUserId);

    await _db.collection("chats").doc(chatId).collection("messages").add({
      "senderId": currentUser,
      "receiverId": otherUserId,
      "text": text,
      "timestamp": FieldValue.serverTimestamp(),
    });

    await NotificationService().sendNotification(
      userId: otherUserId,
      title: "Nouveau message",
      body: text,
    );
  }

  Stream<QuerySnapshot> getMessages(String otherUserId) {
    final chatId = getChatId(otherUserId);

    return _db
        .collection("chats")
        .doc(chatId)
        .collection("messages")
        .orderBy("timestamp")
        .snapshots();
  }
}
